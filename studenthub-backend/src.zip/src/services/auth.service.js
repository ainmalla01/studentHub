// services/auth.service.js

import { prisma } from "../config/prisma.js";
import {
  generateRefreshToken,
  generateToken,
  verifyRefreshToken,
  createAuthPayload,
} from "../utils/jwt.js";
import {
  passwordHash,
  comparePassword,
} from "../utils/password.js";
import { existingUser } from "./UserValidate.service.js";
import AppError from "../utils/AppError.js";

/*
|--------------------------------------------------------------------------
| Register Student
|--------------------------------------------------------------------------
*/
export const register = async (data) => {
  const emailExists = await existingUser(data.email);

  if (emailExists) {
    throw new AppError("User already exists with this email", 409);
  }

  const hashedPassword = await passwordHash(data.password);

  const user = await prisma.user.create({
    data: {
      email: data.email,
      password: hashedPassword,
      role: "STUDENT",

      student: {
        create: {
          fullName: data.fullName,
          specialization: data.specialization,
          phone: data.phone || null,
          collegeId: data.collegeId || null,
          faculty: data.faculty,
          semester: Number(data.semester), // Ensures semester is an integer for Prisma
          batch: data.batch || null,
        },
      },
    },

    include: {
      student: {
        include: {
          skills: true,
          college: true,
        },
      },
    },
  });

  return {
    id: user.id,
    email: user.email,
    role: user.role,
    student: user.student,
  };
};

/*
|--------------------------------------------------------------------------
| Login (Student & College Admin)
|--------------------------------------------------------------------------
*/
export const login = async (data) => {
  const { email, password } = data;

  if (!email || !password) {
    throw new AppError("Email and password are required", 400);
  }

  const user = await prisma.user.findUnique({
    where: { email },
    include: {
      student: {
        include: {
          college: true,
          skills: true,
        },
      },
      college: true,
    },
  });

  if (!user) {
    throw new AppError("Invalid email or password", 401);
  }

  const isMatch = await comparePassword(password, user.password);

  if (!isMatch) {
    throw new AppError("Invalid email or password", 401);
  }

  // Derive active college ID
  const collegeId =
    user.role === "COLLEGE_ADMIN"
      ? user.college?.id ?? null
      : user.student?.collegeId ?? null;

  const tokenPayload = {
    id: user.id,
    role: user.role,
    collegeId,
  };

  const token = generateToken(tokenPayload);
  const refreshToken = generateRefreshToken(tokenPayload);

  return {
    user: {
      id: user.id,
      email: user.email,
      role: user.role,
      collegeId,
      student: user.student,
      college: user.college,
    },
    token,
    refreshToken,
  };
};

/*
|--------------------------------------------------------------------------
| Refresh Token
|--------------------------------------------------------------------------
*/
export const refreshToken = async (refreshTokenValue) => {
  if (!refreshTokenValue) {
    throw new AppError("Refresh token is required", 401);
  }

  const decoded = verifyRefreshToken(refreshTokenValue);

  if (!decoded) {
    throw new AppError("Invalid or expired refresh token", 401);
  }

  // Verify user still exists in DB
  const user = await prisma.user.findUnique({
    where: { id: decoded.id },
    include: {
      student: true,
      college: true,
    },
  });

  if (!user) {
    throw new AppError("User not found", 404);
  }

  // Determine current collegeId directly from database
  const collegeId =
    user.role === "COLLEGE_ADMIN"
      ? user.college?.id ?? null
      : user.student?.collegeId ?? null;

  const payload = {
    id: user.id,
    role: user.role,
    collegeId,
  };

  const accessToken = generateToken(payload);
  const newRefreshToken = generateRefreshToken(payload);

  return {
    accessToken,
    refreshToken: newRefreshToken,
  };
};

/*
|--------------------------------------------------------------------------
| Get Current Logged-In User
|--------------------------------------------------------------------------
*/
export const getMe = async (id) => {
  const user = await prisma.user.findUnique({
    where: { id },
    include: {
      student: {
        include: {
          skills: true,
          college: true,
        },
      },
      college: true,
    },
  });

  if (!user) {
    throw new AppError("User not found", 404);
  }

  return {
    id: user.id,
    email: user.email,
    role: user.role,
    student: user.student,
    college: user.college,
    collegeId:
      user.role === "COLLEGE_ADMIN"
        ? user.college?.id ?? null
        : user.student?.collegeId ?? null,
  };
};