import {prisma} from "../../config/prisma.js";

export const getStudents = async ({ collegeId, query }) => {
  const page = Math.max(Number(query.page) || 1, 1);
  const limit = Math.min(Number(query.limit) || 20, 100);

  const skip = (page - 1) * limit;

  const search = query.search?.trim();
  const faculty = query.faculty;
  const batch = query.batch;
  const semester = query.semester
    ? Number(query.semester)
    : undefined;

  const where = {
    collegeId,

    ...(search && {
      OR: [
        {
          fullName: {
            contains: search,
            mode: "insensitive",
          },
        },
        {
          phone: {
            contains: search,
          },
        },
      ],
    }),

    ...(faculty && {
      faculty,
    }),

    ...(batch && {
      batch,
    }),

    ...(semester && {
      semester,
    }),
  };

  const [students, total] = await Promise.all([
    prisma.student.findMany({
      where,
      skip,
      take: limit,
      orderBy: {
        createdAt: "desc",
      },
    }),

    prisma.student.count({
      where,
    }),
  ]);

  return {
    students,
    pagination: {
      page,
      limit,
      total,
      totalPages: Math.ceil(total / limit),
    },
  };
};

export const getStudentById = async (collegeId, studentId) => {
  return prisma.student.findFirst({
    where: {
      id: studentId,
      collegeId,
    },

    include: {
      skills: true,
    },
  });
};

export const updateStudent = async (
  collegeId,
  studentId,
  data
) => {
  const student = await prisma.student.findFirst({
    where: {
      id: studentId,
      collegeId,
    },
  });

  if (!student) {
    throw new Error("Student not found");
  }

  return prisma.student.update({
    where: {
      id: studentId,
    },
    data,
  });
};