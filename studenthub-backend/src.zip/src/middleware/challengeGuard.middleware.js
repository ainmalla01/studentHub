import { AppError } from "../utils/AppError.js";
import {prisma} from "../config/prisma.js";

/**
 * Checks status, department, AND ensures the student hasn't already submitted.
 */
export const canSubmit = async (req, res, next) => {
  try {
    const challengeId =
      req.params.challengeId ||
      req.params.id ||
      req.body.challengeId ||
      req.query.challengeId;

    const studentId = req.user?.studentId;

    if (!challengeId) {
      throw new AppError(400, "Challenge ID is required.");
    }
    if (!studentId) {
      throw new AppError(401, "Student profile required.");
    }

    // 1. Fetch Challenge Details
    const challenge = await prisma.challenge.findUnique({
      where: { id: challengeId },
      select: { id: true, status: true, department: true },
    });

    if (!challenge) {
      throw new AppError(404, "Challenge not found.");
    }

    // 2. Verify Challenge Status is ACTIVE
    if (challenge.status?.toUpperCase() !== "ACTIVE") {
      throw new AppError(
        400,
        `Submissions are closed. Challenge status is '${challenge.status}'.`
      );
    }

    // 3. Resolve and Verify Department Eligibility
    let studentDepartment = req.user?.department;
    if (!studentDepartment) {
      const student = await prisma.student.findUnique({
        where: { id: studentId },
        select: { department: true },
      });
      studentDepartment = student?.department;
    }

    const challengeDept = challenge.department?.toUpperCase();
    const userDept = studentDepartment?.toUpperCase();

    if (challengeDept !== "ALL" && challengeDept !== userDept) {
      throw new AppError(
        403,
        "Access denied: You cannot submit to challenges outside your department."
      );
    }

    // 4. Check for existing submission
    const existingSubmission = await prisma.submission.findFirst({
      where: {
        challengeId,
        studentId,
      },
    });

    if (existingSubmission) {
      throw new AppError(
        400,
        "You have already submitted a response for this challenge."
      );
    }

    req.challenge = challenge;
    next();
  } catch (error) {
    next(error);
  }
};
/**
 * Ensures the student belongs to the required department and the challenge status is ACTIVE.
 */
export const canParticipate = async (req, res, next) => {
  try {
    const challengeId =
      req.params.challengeId ||
      req.params.id ||
      req.body.challengeId ||
      req.query.challengeId;

    if (!challengeId) {
      throw new AppError(400, "Challenge ID is required.");
    }

    // 1. Fetch challenge details
    const challenge = await prisma.challenge.findUnique({
      where: { id: challengeId },
      select: { id: true, status: true, department: true },
    });

    if (!challenge) {
      throw new AppError(404, "Challenge not found.");
    }

    // 2. Verify Challenge Status is ACTIVE
    if (challenge.status?.toUpperCase() !== "ACTIVE") {
      throw new AppError(
        400,
        `Cannot participate. Challenge status is currently '${challenge.status}'.`
      );
    }

    // 3. Resolve Student Department
    let studentDepartment = req.user?.department;
    if (!studentDepartment && req.user?.studentId) {
      const student = await prisma.student.findUnique({
        where: { id: req.user.studentId },
        select: { department: true },
      });
      studentDepartment = student?.department;
    }

    // 4. Verify Department Eligibility
    const challengeDept = challenge.department?.toUpperCase();
    const userDept = studentDepartment?.toUpperCase();

    if (challengeDept !== "ALL" && challengeDept !== userDept) {
      throw new AppError(
        403,
        "Access denied: You cannot participate in challenges outside your department."
      );
    }

    req.challenge = challenge;
    next();
  } catch (error) {
    next(error);
  }
};