
// middleware/upload.middleware.js

import multer from "multer";

/*
|--------------------------------------------------------------------------
| Storage
|--------------------------------------------------------------------------
|
| Files stay in memory as Buffer objects.
| This is useful when uploading directly to Cloudinary or another
| storage service.
|
*/

const storage = multer.memoryStorage();

/*
|--------------------------------------------------------------------------
| File Filter
|--------------------------------------------------------------------------
|
| Only image files are accepted.
|
*/

const fileFilter = (req, file, cb) => {
  if (file.mimetype.startsWith("image/")) {
    return cb(null, true);
  }

  cb(
    new Error("Only image files are allowed"),
    false
  );
};

/*
|--------------------------------------------------------------------------
| Multer Upload
|--------------------------------------------------------------------------
*/

export const upload = multer({
  storage,

  fileFilter,

  limits: {
    fileSize: 5 * 1024 * 1024, // 5 MB
  },
});

/*
|--------------------------------------------------------------------------
| Reusable Upload Middlewares
|--------------------------------------------------------------------------
*/

export const uploadSingleImage = (fieldName) => {
  return upload.single(fieldName);
};

export const uploadMultipleImages = (
  fieldName,
  maxCount = 5
) => {
  return upload.array(fieldName, maxCount);
};
