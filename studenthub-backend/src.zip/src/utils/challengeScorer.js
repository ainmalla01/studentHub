
export const calculateChallengeMatchScore = (challenge, studentSkills = [], isParticipating = false) => {
  const challengeSkills = challenge.requiredSkills || challenge.skills || [];
  
  // Normalize strings to lowercase for case-insensitive comparison
  const normalizedStudentSkills = new Set(studentSkills.map((s) => s.toLowerCase().trim()));
  const normalizedChallengeSkills = challengeSkills.map((s) => s.toLowerCase().trim());

  if (normalizedChallengeSkills.length === 0) {
    // General challenges with no specific skill requirements get a neutral score
    return { score: 10, matchedSkills: [] };
  }

  // Find overlapping skills
  const matchedSkills = normalizedChallengeSkills.filter((skill) =>
    normalizedStudentSkills.has(skill)
  );

  // Calculate percentage of challenge skills the student possesses
  const matchRatio = matchedSkills.length / normalizedChallengeSkills.length;
  let score = matchRatio * 100;

  // Add bonus points if already enrolled/participating to keep active tasks near top
  if (isParticipating) {
    score += 20;
  }

  return {
    score: Math.round(score),
    matchedSkills,
  };
};

/**
 * Sorts an array of challenges by skill match score (descending) then creation date (newest first).
 */
export const sortChallengesBySkillMatch = (challenges = [], studentSkills = [], participatingIds = new Set()) => {
  return challenges
    .map((challenge) => {
      const isParticipating = participatingIds.has(challenge.id);
      const { score, matchedSkills } = calculateChallengeMatchScore(
        challenge,
        studentSkills,
        isParticipating
      );

      return {
        ...challenge,
        matchScore: score,
        matchedSkills,
        isParticipating,
      };
    })
    .sort((a, b) => {
      // Primary sort: Match Score (descending)
      if (b.matchScore !== a.matchScore) {
        return b.matchScore - a.matchScore;
      }
      // Secondary sort: Creation Date (newest first)
      return new Date(b.createdAt) - new Date(a.createdAt);
    });
};