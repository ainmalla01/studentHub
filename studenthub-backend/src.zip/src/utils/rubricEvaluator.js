/**
 * Evaluates rubric criteria scores and handles verification logic.
 * 
 * Rules:
 * - Sums all criterion points.
 * - If total points >= 80, sets `verified` to true.
 * - If total points < 80, preserves the current `verified` status without change.
 * 
 * @param {Array<Object>} criteria - List of criteria objects with score values.
 * @param {number|string} [criteria[].score] - Points assigned to a criterion.
 * @param {boolean} [currentVerifiedStatus=false] - Existing verified flag from DB.
 * @returns {Object} Evaluation output containing totalScore and updated verified status.
 */
export const evaluateRubric = (criteria = [], currentVerifiedStatus = false) => {
  if (!Array.isArray(criteria)) {
    throw new TypeError("Criteria must be an array of rubric items.");
  }

  // Calculate sum of scores safely handling null, undefined, or string numbers
  const totalScore = criteria.reduce((accumulator, item) => {
    const points = Number(item?.score ?? item?.assignedPoints) || 0;
    return accumulator + points;
  }, 0);

  // Verification threshold logic
  const isEligibleForVerification = totalScore >= 80;

  // Set to true if >= 80; otherwise retain existing status unchanged
  const verified = isEligibleForVerification ? true : Boolean(currentVerifiedStatus);

  return {
    totalScore,
    verified,
  };
};