import { Router } from "express";

import {
  getStudents,
  getStudentById,
  updateStudent,
} from "../../controller/college/students.controller.js";

import { protect } from "../../middleware/protected.middleware.js";

const router = Router();

router.get("/", protect, getStudents);

router.get("/:studentId", protect, getStudentById);

router.patch("/:studentId", protect, updateStudent);

export default router;