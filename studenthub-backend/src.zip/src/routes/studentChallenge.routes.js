import { Router } from "express";
import * as c from "../controllers/studentChallenge.controller.js";
import { asyncHandler } from "../utils/asyncHandler.js";
import { requireAuth, requireRole } from "../middleware/auth.middleware.js";
import { canParticipate, canSubmit } from "../middleware/challengeGuard.middleware.js";

const router = Router();

// ==========================================
// Challenge Discovery & Participation
// ==========================================
router.get(
  "/challenges",
  requireAuth,
  requireRole("STUDENT"),
  asyncHandler(c.getStudentChallenges)
);

router.get(
  "/challenges/:id",
  requireAuth,
  requireRole("STUDENT"),
  asyncHandler(c.getStudentChallenge)
);

router.get(
  "/challenges/:challengeId/rubric",
  requireAuth,
  requireRole("STUDENT"),
  asyncHandler(c.getChallengeRubric)
);

router.post(
  "/challenges/:challengeId/participate",
  requireAuth,
  requireRole("STUDENT"),
  canParticipate,
  asyncHandler(c.participateInChallenge)
);

router.post(
  "/challenges/:challengeId/leave",
  requireAuth,
  requireRole("STUDENT"),
  asyncHandler(c.leaveChallenge)
);

// ==========================================
// Submissions & Workspace
// ==========================================
router.post(
  "/challenges/:challengeId/submit",
  requireAuth,
  requireRole("STUDENT"),
  canSubmit,
  asyncHandler(c.submitChallenge)
);

router.get(
  "/challenges/:challengeId/my-submission",
  requireAuth,
  requireRole("STUDENT"),
  asyncHandler(c.getMyChallengeSubmission)
);

router.put(
  "/challenges/:challengeId/submission",
  requireAuth,
  requireRole("STUDENT"),
  canSubmit,
  asyncHandler(c.updateSubmission)
);

router.get(
  "/submissions",
  requireAuth,
  requireRole("STUDENT"),
  asyncHandler(c.getMySubmissions)
);

// ==========================================
// Leaderboards & Analytics
// ==========================================
router.get(
  "/challenges/:challengeId/leaderboard",
  requireAuth,
  requireRole("STUDENT"),
  asyncHandler(c.getChallengeLeaderboard)
);

export default router;