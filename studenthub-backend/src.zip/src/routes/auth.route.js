
import express from "express";

import {
  register,
  login,
  logout,
  getMe,
  refreshToken,
} from "../controller/auth.controller.js";

import { validate } from "../middleware/validate.js";
import { protect } from "../middleware/protected.middleware.js";

import {
  loginSchema,
  registerSchema,
} from "../validations/auth.validation.js";

const router = express.Router();

/*
|--------------------------------------------------------------------------
| Public Authentication Routes
|--------------------------------------------------------------------------
*/

// Register student/account
router.post(
  "/register",
  validate(registerSchema),
  register
);

// Login student / college admin
router.post(
  "/login",
  validate(loginSchema),
  login
);

// Refresh access token
router.post(
  "/refresh-token",
  refreshToken
);

/*
|--------------------------------------------------------------------------
| Protected Authentication Routes
|--------------------------------------------------------------------------
*/

// Logout authenticated user
router.post(
  "/logout",
  protect,
  logout
);

// Get currently authenticated user
router.get(
  "/me",
  protect,
  getMe
);

export default router;

