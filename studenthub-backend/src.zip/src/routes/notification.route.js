// studenthub-backend/src/routes/notification.routes.js

import express from 'express';
import {
  getNotifications,
  markAsRead,
  markAllAsRead,
  deleteNotification,
} from '../controllers/notification.controller.js'; // Adjust relative path if needed
import { requireAuth } from '../middleware/auth.middleware.js';
const router = express.Router();

router.get('/', requireAuth,getNotifications);
router.patch('/read-all', markAllAsRead);
router.patch('/:id/read', markAsRead);
router.delete('/:id', deleteNotification);

export default router;