import { v2 as cloudinary } from "cloudinary";

export const studentDefult_image = async () => {
  // Configure Cloudinary inside the function to guarantee process.env is ready
  cloudinary.config({
    cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
    api_key: process.env.CLOUDINARY_API_KEY,
    api_secret: process.env.CLOUDINARY_API_SECRET,
  });

  const url = cloudinary.url("profile_s5vxxp", {
    secure: true,
    resource_type: "image",
  });

  return url;
};

export default cloudinary;