import { Router } from "express";
import * as c from "../controllers/auth.controller.js";
import { asyncHandler } from "../utils/asyncHandler.js";
import { requireAuth } from "../middleware/auth.middleware.js";

const router = Router();

// College Registration & Authentication
router.post("/college/register", asyncHandler(c.registerCollege));
router.post("/college/login", asyncHandler(c.loginCollege));

// Student Authentication
router.post("/student/login", asyncHandler(c.loginStudent));
router.post("/student/resetpassword", requireAuth, asyncHandler(c.resetPassword)); // Fixed typo resetPassowrd -> resetPassword

// Current Session
router.get("/me", requireAuth, asyncHandler(c.me));

// College Status
router.get("/college/status", asyncHandler(c.getCollegeStatus));

// checking ckeckpassword
router.get(
  "/student/check-password",
  requireAuth,
  asyncHandler(c.checkUser)
);

// Logout
router.post("/logout", asyncHandler(c.logout));

export default router;