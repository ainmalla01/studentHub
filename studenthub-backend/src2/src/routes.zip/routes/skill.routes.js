// skill.routes.js
import express from "express";
import { createSkillsController,getSkills } from "../controllers/skill.controller.js";

const router = express.Router();
router.get("/", getSkills);

router.post("/bulk", createSkillsController);

export default router;