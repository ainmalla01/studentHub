// aiSkill.routes.js
import express from "express";
import { generateSkillsController } from "../controllers/aiSkill.controller.js";

const router = express.Router();

router.post("/generate", generateSkillsController);

export default router;