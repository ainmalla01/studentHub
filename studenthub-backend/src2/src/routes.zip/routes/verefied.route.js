import checkStudentVerified from '../controllers/verefied.controller.js'

// getting student Id through token
router.get("/student/verified",studentIdgetting,checkStudentVerified)