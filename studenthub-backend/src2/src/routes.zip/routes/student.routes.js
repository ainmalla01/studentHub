// src/routes/student.routes.js
import { Router } from 'express';
import * as c from '../controllers/student.controller.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { requireAuth, requireRole } from '../middleware/auth.middleware.js';

const router = Router();

// College-only actions (Protected by authentication & role check)
router.post('/', requireAuth, requireRole('COLLEGE'), asyncHandler(c.createStudent));
router.patch('/:id', requireAuth, requireRole('COLLEGE'), asyncHandler(c.updateStudent));
router.delete('/:id', requireAuth, requireRole('COLLEGE'), asyncHandler(c.deleteStudent));

// Student directory & lookups (Ordered correctly to prevent path collision)
router.get('/', asyncHandler(c.getStudents));
router.get('/count', asyncHandler(c.getStudentCount));
router.get('/student-id/:studentId', asyncHandler(c.getStudentByStudentId));
router.get('/:id/stats', asyncHandler(c.getStudentStats));
router.get('/:id', asyncHandler(c.getStudent));

export default router;