import { z } from "zod";
import * as service from "../services/submission.service.js";

import { AppError } from "../utils/AppError.js";
import { ok } from "../utils/response.js";

import {
  createSubmissionSchema,
  evaluateSubmissionSchema,
  submissionQuery,
} from "../validators/submission.validator.js";

import { uuidParam } from "../validators/common.js";

// ============================================================
// SUBMISSION CONTROLLER
// ============================================================

// ============================================================
// STUDENT PORTAL
// ============================================================

// ------------------------------------------------------------
// Submit Work
// ------------------------------------------------------------

export const createSubmission = async (req, res) => {
  const data = createSubmissionSchema.parse(req.body);
  const params = uuidParam.parse(req.params);

  return ok(
    res,
    await service.createSubmission(
      req.user.studentId,
      data,
      params.id
    ),
    "Submission created.",
    201
  );
};

// ------------------------------------------------------------
// My Submissions
// ------------------------------------------------------------
// Student gets ONLY their own submissions.
// Student ID comes from the authenticated JWT.
// ------------------------------------------------------------

export const getMySubmissions = async (req, res) => {
  console.log("[MY SUBMISSIONS] req.user:", req.user);

  const studentId = req.user?.studentId;

  console.log("[MY SUBMISSIONS] studentId:", studentId);

  if (!studentId) {
    throw new AppError(
      403,
      "Student ID not found in authentication."
    );
  }

  const submissions =
    await service.getStudentSubmissions(studentId);

  console.log(
    "[MY SUBMISSIONS] Found:",
    submissions.length
  );

  return ok(res, submissions);
};

// ============================================================
// COLLEGE PORTAL
// ============================================================

// ------------------------------------------------------------
// View / Filter All Submissions
// ------------------------------------------------------------

export const getSubmissions = async (req, res) => {
  return ok(
    res,
    await service.getSubmissions(
      submissionQuery.parse(req.query)
    )
  );
};

// ------------------------------------------------------------
// View Submissions By Student
// ------------------------------------------------------------
// College can view a particular student's submissions.
// ------------------------------------------------------------

export const getStudentSubmissions = async (req, res) => {
  const { studentId } = z
    .object({
      studentId: z.string().uuid(),
    })
    .parse(req.params);

  return ok(
    res,
    await service.getStudentSubmissions(studentId)
  );
};

// ------------------------------------------------------------
// View Submission Details
// ------------------------------------------------------------

export const getSubmission = async (req, res) => {
  const { id } = uuidParam.parse(req.params);

  return ok(
    res,
    await service.getSubmissionById(id)
  );
};

// ------------------------------------------------------------
// View Challenge Submissions
// ------------------------------------------------------------

export const getChallengeSubmissions = async (req, res) => {
  const { challengeId } = z
    .object({
      challengeId: z.string().uuid(),
    })
    .parse(req.params);

  return ok(
    res,
    await service.getChallengeSubmissions(challengeId)
  );
};

// ------------------------------------------------------------
// Mark Submission Under Review
// ------------------------------------------------------------

export const markUnderReview = async (req, res) => {
  const { id } = uuidParam.parse(req.params);

  return ok(
    res,
    await service.markUnderReview(id),
    "Submission moved to review."
  );
};

// ------------------------------------------------------------
// Evaluate Submission
// ------------------------------------------------------------

export const evaluateSubmission = async (req, res) => {
  const { id } = uuidParam.parse(req.params);

  const data = evaluateSubmissionSchema.parse(req.body);

  return ok(
    res,
    await service.evaluateSubmission(id, data),
    "Submission evaluated."
  );
};

// ------------------------------------------------------------
// Submission Statistics
// ------------------------------------------------------------

export const getStatistics = async (_req, res) => {
  return ok(
    res,
    await service.getSubmissionStatistics()
  );
};